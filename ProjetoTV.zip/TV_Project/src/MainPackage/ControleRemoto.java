package MainPackage;

import java.util.ArrayList;

public class ControleRemoto {

    ArrayList<Televisao> listaTV = new ArrayList();

    Televisao tv = new Televisao();

    public void adicionarTV(Televisao tv) {
        if (!listaTV.contains(tv)) {
            listaTV.add(tv);
        } else {
            System.out.println("TV já cadastrada...");
        }
    }

    public void aumentarVolume() {
        listaTV.forEach((TV) -> {
            TV.alterarVolume(true);
        });
    }

    public void diminuirVolume() {
        listaTV.forEach((TV) -> {
            TV.alterarVolume(false);
        });
    }

    public void sintonizarCanalEspecifico(int numCanal) {
        listaTV.forEach((TV) -> {
            TV.sintonizar(numCanal);
        });
    }

    public void proxCanal() {
        listaTV.forEach((TV) -> {
            TV.alterarCanal("Proximo");
        });
    }

    public void canalAnterior() {
        listaTV.forEach((TV) -> {
            TV.alterarCanal("Anterior");
        });
    }
    
    public void informarDados() {
        listaTV.forEach((TV) -> {
            TV.informarDados();
        });
    }

    public void mostrarGrade() {
        listaTV.forEach((TV) -> {
            TV.mostrarGrade();
        });
    }
}
