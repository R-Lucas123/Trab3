package MainPackage;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Televisao {

    Scanner input = new Scanner(System.in);

    protected String id;
    protected int volume;
    protected String canalAtual;
    protected final int volumeMaximo = 10;
    protected final int volumeMinimo = 0;

    ArrayList<Canal> canaisCadastrados = new ArrayList();
    ArrayList<Canal> canaisDisponiveis = new ArrayList();

    public void Televisao(String id, int volume, String canalAtual) {
        this.id = id;
        this.volume = volume;
        this.canalAtual = canalAtual;
    }

    public void Televisao(ArrayList canaisDisp) {
        this.canaisDisponiveis.addAll(canaisDisp);
        this.volume = 5;
    }

    public void alterarVolume(boolean aumentarVol) {
        if (aumentarVol && volume < volumeMaximo) {
            volume++;
        } else if (!aumentarVol && volume > volumeMinimo) {
            volume--;
        }
    }

    public void cadastrarCanais() {

    }

    public boolean verificarCanalExistente(String canal) {
        Iterator<Canal> itr = canaisDisponiveis.iterator();
        while (itr.hasNext()) {
            Canal aux = itr.next();
            if (aux.getNome().equals(canal)) {
                return true;
            }
        }
        return false;
    }

    public void sintonizar(int numCanal) {
        Iterator<Canal> itr = canaisDisponiveis.iterator();
        boolean canalAlterado = false;
        while (itr.hasNext()) {
            Canal aux = itr.next();
            if (aux.getNumero().equals(numCanal)) {
                canalAtual = aux.getNome();
                canalAlterado = true;
            }
        }
        if (!canalAlterado) {
            System.out.println("Canal inexistente...");
        }
    }

    public void alterarCanal(String alterarCanal) {
        if (!this.canaisDisponiveis.isEmpty()) {
            if (alterarCanal.equalsIgnoreCase("Proximo")) {
                Iterator<Canal> itr = canaisDisponiveis.iterator();
                Canal primeiroCanal = itr.next();
                while (itr.hasNext()) {
                    Canal aux = itr.next();
                    if (aux.getNome().equals(canalAtual)) {
                        if (canaisDisponiveis.indexOf(aux) == canaisDisponiveis.size()) {
                            canalAtual = primeiroCanal.getNome();
                        } else {
                            aux = itr.next();
                            canalAtual = aux.getNome();
                        }
                        break;
                    }
                }
            } else if (alterarCanal.equalsIgnoreCase("Anterior")) {
                Iterator<Canal> itr = canaisDisponiveis.iterator();
                Canal primeiroCanal = itr.next();
                while (itr.hasNext()) {
                    Canal aux = itr.next();
                    if (canalAtual.equals(primeiroCanal.getNome())) {
                        canalAtual = canaisDisponiveis.get(canaisDisponiveis.size()).getNome();
                    } else if (itr.next().getNome().equals(canalAtual)) {
                        canalAtual = aux.getNome();
                    }
                }
            }
        }
    }

    public void informarDados() {
        if (this.canaisDisponiveis.isEmpty()) {
            System.out.println("\nNenhum canal disponível...\n");
        } else {
            Iterator<Canal> itr = canaisDisponiveis.iterator();
            while (itr.hasNext()) {
                Canal aux = itr.next();
                if (aux.getNome().equals(canalAtual)) {
                    System.out.println("\nInformações do canal...");
                    System.out.println("Nome: " + aux.getNome());
                    System.out.println("Número: " + aux.getNumero());
                    System.out.println("HD: " + aux.isHD());
                    System.out.println("Volume: " + volume);
                    break;
                }
            }
        }
        System.out.print("\nPressione qualquer tecla para continuar...");
        String pause = input.nextLine();
    }

    public void mostrarGrade() {
        Iterator<Canal> itr = canaisCadastrados.iterator();
        while (itr.hasNext()) {
            Canal aux = itr.next();
            System.out.println("\nInformações do canal...");
            System.out.println("Nome: " + aux.getNome());
            System.out.println("Número: " + aux.getNumero());
            System.out.println("HD: " + aux.isHD());
            System.out.println("Volume: " + volume);
        }
        System.out.print("\nPressione qualquer tecla para continuar...");
        String pause = input.nextLine();
    }

    public int getVolume() {
        return this.volume;
    }

    public void setVolume(int volume) {
        this.volume = volume;
    }

    public String getCanalAtual() {
        return canalAtual;
    }

    public void setCanal(String canalAtual) {
        this.canalAtual = canalAtual;
    }
}
