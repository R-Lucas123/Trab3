package MainPackage;

import java.util.ArrayList;

public class SmartTV extends Televisao {

    Televisao tv = new Televisao();

    protected int qtdPolegadas;

    public void SmartTV(String id, String canalAtual, int volume, int qtdPolegadas) {
        this.id = id;
        this.canalAtual = canalAtual;
        this.volume = volume;
        this.qtdPolegadas = qtdPolegadas;
    }

    public void SmartTV(int qtdPolegadas) {
        this.qtdPolegadas = qtdPolegadas;
    }

    public void cadastrarCanais(ArrayList canaisCad) {
        this.canaisDisponiveis.clear();
        this.canaisDisponiveis.addAll(canaisCad);
        Televisao(this.canaisDisponiveis);
        this.canalAtual = this.canaisDisponiveis.get(0).getNome();
    }
}
