package MainPackage;

import java.util.Scanner;

public class ClassePrincipal {

    public static void main(String[] args) throws Exception {
        Scanner input = new Scanner(System.in);

        ControleRemoto controleRemoto = new ControleRemoto();
        Televisao tv = new Televisao();
        SmartTV smartTv = new SmartTV();
        TVHD tvHd = new TVHD();

        smartTv.SmartTV("Smart2020", null, 5, 32);
        tvHd.TVHD("HD-TV", null, 5, "Philco");

        controleRemoto.listaTV.add(smartTv);
        controleRemoto.listaTV.add(tvHd);

        String tvSelecionada = "SmartTV";

        while (true) {
            limparTela();

            if (tvSelecionada.equals("SmartTV")) {
                System.out.println("Tv selecionada: SmartTv\n");
            } else if (tvSelecionada.equals("TVHD")) {
                System.out.println("Tv selecionada: TVHD\n");
            }

            System.out.println("1- Selecionar TV");
            System.out.println("2- Cadastrar canal");
            System.out.println("3- Acessar controle remoto");
            System.out.print("Opção: ");
            String opcao = input.nextLine();
            limparTela();

            switch (opcao) {
                case "1":
                    System.out.println("1- SmartTV");
                    System.out.print("2- TVHD: ");
                    opcao = input.nextLine();

                    if (opcao.equals("1")) {
                        tvSelecionada = "SmartTV";
                    } else {
                        tvSelecionada = "TVHD";
                    }
                    break;

                case "2":
                    System.out.print("Número: ");
                    String numero = input.nextLine();

                    System.out.print("Nome: ");
                    String nome = input.nextLine();

                    System.out.print("HD: \n 1- Sim\n 2- Não:");
                    String ishd = input.nextLine();
                    boolean hd = ishd.equals("1");

                    Canal novoCanal = new Canal(numero, nome, hd);
                    tv.canaisCadastrados.add(novoCanal);
                    break;

                case "3":
                    boolean continuar = true;
                    while (continuar == true) {
                        if (tv.canaisCadastrados.isEmpty()) {
                            System.out.println("\nNenhum canal cadastrado...\n\n");
                        } else {
                            if (tvSelecionada.equals("SmartTV")) {
                                smartTv.cadastrarCanais(tv.canaisCadastrados);

                                System.out.println("--SMART TV--");
                                System.out.println("ID: " + smartTv.id);
                                System.out.println("Volume: " + smartTv.volume);
                                System.out.println("Canal atual: " + smartTv.canalAtual);
                                System.out.println("Polegadas: " + smartTv.qtdPolegadas);

                            } else if (tvSelecionada.equals("TVHD")) {
                                tvHd.cadastrarCanais(tv.canaisCadastrados);

                                System.out.println("--TVHD--");
                                System.out.println("ID: " + tvHd.id);
                                System.out.println("Volume: " + tv.volume);
                                System.out.println("Canal atual: " + tv.canalAtual);
                                System.out.println("Modelo: " + tvHd.modelo);
                            }
                        }

                        System.out.println("\n");
                        System.out.println("1- Aumentar volume");
                        System.out.println("2- Diminuir volume");
                        System.out.println("3- Sintonizar canal específico");
                        System.out.println("4- Próximo canal");
                        System.out.println("5- Canal anterior");
                        System.out.println("6- Informar dados");
                        System.out.println("7- Mostrar grade");
                        System.out.println("8- Voltar para o menu");
                        System.out.print("Opção: ");
                        String opControle = input.nextLine();

                        switch (opControle) {
                            case "1":
                                controleRemoto.aumentarVolume();
                                limparTela();
                                break;

                            case "2":
                                controleRemoto.diminuirVolume();
                                limparTela();
                                break;

                            case "3":
                                System.out.print("Número do canal: ");
                                int numCanal = input.nextInt();
                                controleRemoto.sintonizarCanalEspecifico(numCanal);
                                limparTela();
                                break;

                            case "4":
                                controleRemoto.proxCanal();
                                limparTela();
                                break;

                            case "5":
                                controleRemoto.canalAnterior();
                                limparTela();
                                break;

                            case "6":
                                limparTela();
                                if (tvSelecionada.equals("SmartTV")) {
                                    smartTv.informarDados();
                                } else if (tvSelecionada.equals("TVHD")) {
                                    tvHd.informarDados();
                                }
                                limparTela();
                                break;

                            case "7":
                                tv.mostrarGrade();
                                limparTela();
                                break;

                            case "8":
                                continuar = false;
                                limparTela();
                                break;

                            default:
                                System.out.println("\nOpção inválida...\n");
                        }
                    }
            }
        }
    }

    public static void limparTela() {
        for (int i = 0; i < 40; i++) {
            System.out.println("");
        }
        System.out.println("------------------------------------------------");
    }
}
