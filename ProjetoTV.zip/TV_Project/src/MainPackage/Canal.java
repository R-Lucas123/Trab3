package MainPackage;

public class Canal {

    private String numero;
    private String nome;
    private boolean HD;

    public Canal(String numero, String nome, boolean hd) {
        this.numero = numero;
        this.nome = nome;
        this.HD = hd;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public boolean isHD() {
        return HD;
    }

    public void setHD(boolean HD) {
        this.HD = HD;
    }
}
