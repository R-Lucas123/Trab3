package MainPackage;

import java.util.ArrayList;
import java.util.Iterator;

public class TVHD extends Televisao {

    protected String modelo;

    public void TVHD(String id,  String canalAtual, int volume, String modelo) {
        this.id = id;
        this.canalAtual = canalAtual;
        this.volume = volume;
        this.modelo = modelo;
    }

    public void TVDH(String modelo) {
        this.modelo = modelo;
    }

    public void cadastrarCanais(ArrayList canaisCad) {
        this.canaisDisponiveis.clear();
        Iterator<Canal> itr = canaisCad.iterator();
        while (itr.hasNext()) {
            Canal aux = itr.next();
            if (aux.isHD()) {
                this.canaisDisponiveis.add(aux);
            }
        }
        if (!this.canaisDisponiveis.isEmpty()) {
            this.canalAtual = this.canaisDisponiveis.get(this.canaisDisponiveis.size() - 1).getNome();
        }
    }
}
